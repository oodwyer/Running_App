package com.example.afinal

import android.app.Activity
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import kotlinx.android.synthetic.main.run_display.view.*

class RecyclerAdapter(var activity: Activity,
                      var runs:List<Run>,
                      var listener: (Int) -> Unit) : RecyclerView.Adapter<ViewHolderClick>() {
    //gets the number of items in the list
    override fun getItemCount() = runs.size

    // create viewholder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderClick =
        ViewHolderClick(LayoutInflater.from(activity).inflate(R.layout.run_display, parent, false))

    // binds the contact info to the viewholder
    override fun onBindViewHolder(holder: ViewHolderClick, position: Int) =
        holder.bind(runs[position], position, listener)
}

class ViewHolderClick(view: View) : RecyclerView.ViewHolder(view){
    var name: TextView = view.runName
    var number: TextView = view.runMiles
    var view: View = view

    // for binding contact info to view
    fun bind(item: Run, position : Int, listener: (Int) -> Unit) {
        name.text = item.name
        number.text = item.number

        // sets up the onClickListener to the entire view
        view.setOnClickListener{
            listener(position)
        }
    }
}
