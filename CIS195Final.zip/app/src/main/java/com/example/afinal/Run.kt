package com.example.afinal

class Run(var name: String, var number: String?) {



}