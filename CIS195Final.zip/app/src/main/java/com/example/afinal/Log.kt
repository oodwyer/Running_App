package com.example.afinal

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity;

import kotlinx.android.synthetic.main.activity_log.*

class Log : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

            //name.text = intent.getStringExtra("name")
            //phone_number.text = intent.getStringExtra("number")
            //image.setImageBitmap(intent.getParcelableExtra<Bitmap>("photo"))
        logbutton.setOnClickListener {
            //add log click listener

            val sharedPref = this?.getSharedPreferences("totalMiles",
                Context.MODE_PRIVATE)
            with (sharedPref.edit()) {
                clear()
                var totalVal = sharedPref.getString("total", "0.0")
                var miles = number.text.toString().toDouble()
                var num = totalVal.toDouble()
                totalVal = (num + miles).toString()
                    putString("total", totalVal)
                    commit()
            }

            /*val sharedPrefRuns = this?.getSharedPreferences("runData",
                Context.MODE_PRIVATE)
            with (sharedPref.edit()) {
                val currNames = sharedPref.getString("values", "")
                if (currNames.isEmpty()) {
                    putString("names", name.text.toString())
                    commit()
                } else {
                    putString("values", currNames +"|"+name.text.toString())
                    commit()
                }
                putInt(name.text.toString()+"_number", number.text.toString().toInt())
                commit()
            }*/

            val name = name.text.toString()
            val number = number.text.toString()

            if (!number.isEmpty() && !name.isEmpty()) {
                val sharedPref = this?.getSharedPreferences("runData", Context.MODE_PRIVATE)
                val editor = sharedPref.edit()
                val currNames = sharedPref.getString("names", "")
                if (currNames.isEmpty()) {
                    editor.putString("names", name)
                } else {
                    editor.putString("names", currNames +"|"+name)
                }
                editor.putString(name+"_number", number)
                editor.commit()
            }
            finish()

            //val miles = number.text.toString()
            // intent.putExtra("miles", miles)
            val intent = Intent(this, Stats::class.java)
            startActivity(intent)
        }

    }

}
