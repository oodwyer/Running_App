package com.example.afinal

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_stats.*


class Stats : AppCompatActivity() {
    private var total = 0.0
    private val runs: ArrayList<Run> = ArrayList()

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_dashboard -> {
                val intent = Intent(this, Trails::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_notifications -> {
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        //addRunData()

        val sharedPrefRuns = this?.getSharedPreferences("runData", Context.MODE_PRIVATE)
        val names = sharedPrefRuns.getString("names", "").split("|")
        if (!sharedPrefRuns.getString("names","").isEmpty()) {
            for (name in names) {
                val number = sharedPrefRuns.getString(name+"_number", "")
                val run = Run(name, number)
                runs.add(run)
            }
        }

        val sharedPref = this?.getSharedPreferences("totalMiles", Context.MODE_PRIVATE)
        var total = sharedPref.getString("total", "0.0")


        //var miles = intent.getStringExtra("miles")
        //if (miles == null) {
        //    miles = "0.0"
        //}
        //total += miles.toDouble()
        textView.text = total.toString()

        navigationStats.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)

        clear.setOnClickListener {
            val editor = sharedPref.edit()
            editor.clear()
            editor.commit()

            val editorTwo = sharedPrefRuns.edit()
            editorTwo.clear()
            editorTwo.commit()

            var total = sharedPref.getString("total", "0.0")
            textView.text = total.toString()

            val sharedPrefRuns = this?.getSharedPreferences("runData", Context.MODE_PRIVATE)
            val names = sharedPrefRuns.getString("names", "").split("|")
            if (!sharedPrefRuns.getString("names","").isEmpty()) {
                for (name in names) {
                    val number = sharedPrefRuns.getString(name+"_number", "")
                    val run = Run(name, number)
                    runs.add(run)
                }
            }

            recycler_view.layoutManager = LinearLayoutManager(this)
            //adapter with click listener
            recycler_view.adapter = RecyclerAdapter(this, runs) {
                // do something when clicked
                    position ->
                val intent = Intent(this,RunActivity::class.java)

                intent.putExtra("name", runs[position].name)
                intent.putExtra("number", runs[position].number)

                startActivity(intent)

            }

            val intent = Intent(this, Stats::class.java)
            startActivity(intent)

        }

        recycler_view.layoutManager = LinearLayoutManager(this)
        //adapter with click listener
        recycler_view.adapter = RecyclerAdapter(this, runs) {
            // do something when clicked
                position ->
            val intent = Intent(this,RunActivity::class.java)

            intent.putExtra("name", runs[position].name)
            intent.putExtra("number", runs[position].number)

            startActivity(intent)

        }
    }

    /*private fun addRunData() {
        val test1 = Run("Saturday Morning", "3.4")
        val test2 = Run("Sunday Morning", "1.8")
        val test3 = Run("Monday Afternoon", "4")

        runs.add(test1)
        runs.add(test2)
        runs.add(test3)

    }*/


}
