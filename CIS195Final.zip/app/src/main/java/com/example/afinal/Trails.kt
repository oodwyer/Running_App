package com.example.afinal

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import kotlinx.android.synthetic.main.activity_stats.*
import kotlinx.android.synthetic.main.activity_trails.*
import com.yelp.fusion.client.models.Business



class Trails : AppCompatActivity() {
    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_dashboard -> {

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_notifications -> {
                val intent = Intent(this, Stats::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trails)

        navigationTrails.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)

        var trails = intent.getStringArrayExtra("trails")
        if (trails == null) {
            trails = arrayOf("Go to maps to find trails near you!")
        }

        var totalNumberOfResult = trails.size // 3
        if (totalNumberOfResult > 20) {
            totalNumberOfResult = 20
        }


        //val businesses = searchResponse.getBusinesses()
        //val businessName = businesses.get(0).getName()  // "JapaCurry Truck"
        //val rating = businesses.get(0).getRating()  // 4.0
        var text = ""
        for (i in 0 until totalNumberOfResult)
        {
            text += trails.get(i) + "\n"
        }
        trailList.setText(text)

        search.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }

    }

    /*override fun onStart() {
        var trails = intent.getStringArrayExtra("trails")
        if (trails == null) {
            trails = arrayOf("Trail")
        }

        var totalNumberOfResult = trails.size // 3
        if (totalNumberOfResult > 20) {
            totalNumberOfResult = 20
        }


        //val businesses = searchResponse.getBusinesses()
        //val businessName = businesses.get(0).getName()  // "JapaCurry Truck"
        //val rating = businesses.get(0).getRating()  // 4.0
        var text = ""
        for (i in 0 until totalNumberOfResult)
        {
            text += trails.get(i) + "\n"
        }
        trailList.setText(text)
        super.onStart()
    }


    override fun onResume() {
        var trails = intent.getStringArrayExtra("trails")
        if (trails == null) {
            trails = arrayOf("Trail")
        }

        var totalNumberOfResult = trails.size // 3
        if (totalNumberOfResult > 20) {
            totalNumberOfResult = 20
        }


        //val businesses = searchResponse.getBusinesses()
        //val businessName = businesses.get(0).getName()  // "JapaCurry Truck"
        //val rating = businesses.get(0).getRating()  // 4.0
        var text = ""
        for (i in 0 until totalNumberOfResult)
        {
            text += trails.get(i) + "\n"
        }
        trailList.setText(text)
        super.onResume()
    }
*/

}
