package com.example.afinal

import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.widget.Toast

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import android.support.v4.content.ContextCompat
import android.util.Log
import com.google.android.gms.tasks.Task
import android.support.annotation.NonNull
import android.support.v4.app.FragmentActivity
import com.google.android.gms.tasks.OnCompleteListener
import android.provider.SettingsSlicesContract.KEY_LOCATION
import android.support.design.widget.BottomNavigationView
import android.support.v4.content.ContextCompat.startActivity
import android.view.View
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.common.api.Status
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.Marker
import com.yelp.fusion.client.connection.YelpFusionApiFactory
import com.yelp.fusion.client.models.Business
import com.yelp.fusion.client.models.SearchResponse

import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONException

import java.util.Arrays.asList

import org.json.JSONObject
import org.json.JSONTokener
import retrofit2.Call
import retrofit2.Callback
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import kotlin.math.round


class MapsActivity : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnMyLocationButtonClickListener,
    GoogleMap.OnMyLocationClickListener, GoogleMap.OnMapClickListener, GoogleMap.OnMapLongClickListener,
    GoogleMap.OnMarkerDragListener {

    private lateinit var mMap: GoogleMap
    private var mLastKnownLocation: Location? = null
    private var mLocationPermissionGranted = false
    private final var DEFAULT_ZOOM = 10.toFloat()
    val PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1
    var mGeoDataClient = null
    var mPlaceDetectionClient = null
    lateinit var mFusedLocationProviderClient: FusedLocationProviderClient
    val mDefaultLocation = LatLng(-34.0, 151.0)
    protected var defaultLat : Double = -34.0
    protected var defaultLong: Double = 151.0
    val API_KEY = "soZ0YyMTI2eAP7TMNWr1le9xkEHgpTvD0ZuRfzpWa0aOcODvN6sJO9mEGbTd9cwslSkR_y38lpXIX2w4bD2Mg9eJApnxqc6P2cAxBJ9I2N7W9jTCiSsYLPgJl63AXHYx"
    private var apiFactory = YelpFusionApiFactory()
    private var yelpFusionApi = apiFactory.createAPI(API_KEY)


    private val KEY_CAMERA_POSITION = "camera_position"
    private val KEY_LOCATION = "location"



    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_dashboard -> {
                val intent = Intent(this, Trails::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_notifications -> {
                val intent = Intent(this, Stats::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)



        // Initialize Places
        //Places.initialize(getApplicationContext(), getString(R.string.google_maps_key))

// Create a new Places client instance.
        //val placesClient = Places.createClient(this)

        // Initialize the AutocompleteSupportFragment.
        /*val autocompleteFragment = supportFragmentManager.findFragmentById(R.id.search_text)
                as AutocompleteSupportFragment?

// Specify the types of place data to return.
        autocompleteFragment!!.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME))

// Set up a PlaceSelectionListener to handle the response.
        autocompleteFragment.setOnPlaceSelectedListener(object : PlaceSelectionListener {
            override fun onPlaceSelected(place: Place) {
                // TODO: Get info about the selected place.
                Log.i("autocomplete fragment", "Place: " + place.name + ", " + place.id)
            }

            override fun onError(status: Status) {
                // TODO: Handle the error.
                Log.i("autocomplete fragment", "An error occurred: " + status)
            }
        })*/


        //onMapReady()
        //setUpMap()

        // Construct a GeoDataClient.
        //mGeoDataClient = Places.getGeoDataClient(this, null);

        // Construct a PlaceDetectionClient.
        //mPlaceDetectionClient = Places.getPlaceDetectionClient(this, null);

        // Construct a FusedLocationProviderClient.
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        /*super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            mCurrentLocation = savedInstanceState.getParcelable(KEY_LOCATION);
            mCameraPosition = savedInstanceState.getParcelable(KEY_CAMERA_POSITION);
        }*/

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.setOnMapClickListener(this);
        mMap.setOnMapLongClickListener(this);

        setUpMap()

        // Add a marker in Sydney and move the camera
        val sydney = LatLng(-34.0, 151.0)
        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))

        // Turn on the My Location layer and the related control on the map.
        updateLocationUI()

        // Get the current location of the device and set the position of the map.
        getDeviceLocation()

        mMap.addMarker(MarkerOptions()
            .position(LatLng(defaultLat, defaultLong))
            .title("Hello world"))
    }

    private fun setUpMap() {
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 123)
            return
        }
        mMap.isMyLocationEnabled = true
        mMap.setOnMyLocationButtonClickListener(this);
        mMap.setOnMyLocationClickListener(this);
    }

    // what happens when you click on your location
    override fun onMyLocationClick(location: Location) {
        Toast.makeText(this, "Current location:\n" + location, Toast.LENGTH_LONG).show()
    }

    // when the myLocationButton is clicked →
    override fun onMyLocationButtonClick(): Boolean {
        Toast.makeText(this, "MyLocation button clicked", Toast.LENGTH_SHORT).show()
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).
        return false
    }

    private fun updateLocationUI() {
        if (mMap == null) {
            return
        }
        try {
            if (mLocationPermissionGranted) {
                mMap.isMyLocationEnabled = true
                mMap.uiSettings.isMyLocationButtonEnabled = true
            } else {
                mMap.isMyLocationEnabled = false
                mMap.uiSettings.isMyLocationButtonEnabled = false
                mLastKnownLocation = null
                getLocationPermission()
            }
        } catch (e: SecurityException) {
            Log.e("Exception: %s", e.message)
        }

    }

    private fun getLocationPermission() {
        /*
     * Request location permission, so that we can get the location of the
     * device. The result of the permission request is handled by a callback,
     * onRequestPermissionsResult.
     */
        if (ContextCompat.checkSelfPermission(
                this.applicationContext,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mLocationPermissionGranted = true
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION
            )
        }
    }

    private fun getDeviceLocation() {
        /*
     * Get the best and most recent location of the device, which may be null in rare
     * cases when a location is not available.
     */
        try {
            if (mLocationPermissionGranted) {
                val locationResult = mFusedLocationProviderClient.getLastLocation()

                //locationResult.result?.latitude
                //locationResult.result?.longitude

                locationResult.addOnCompleteListener {
                    if (it.isSuccessful) {
                        mMap.moveCamera(
                            CameraUpdateFactory.newLatLngZoom(
                                LatLng(
                                    locationResult.result!!.latitude,
                                    locationResult.result!!.longitude
                                ), DEFAULT_ZOOM
                            )
                        )
                        defaultLat = locationResult.result!!.latitude
                        defaultLong = locationResult.result!!.longitude
                        /*val marker = mMap.addMarker(MarkerOptions()
                            .position(LatLng(defaultLat, defaultLong))
                            .title("Where do you want to run?"))
                        marker.isDraggable*/
                        mMap.setOnMarkerDragListener(this)


                    } else {
                        //Log.d(FragmentActivity.TAG, "Current location is null. Using defaults.")
                        //Log.e(FragmentActivity.TAG, "Exception: %s", task.exception)
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mDefaultLocation, DEFAULT_ZOOM))
                        mMap.uiSettings.isMyLocationButtonEnabled = false
                    }

                    /*override fun onComplete(task: Task<Location!>) {
                        if (task.isSuccessful) {
                            // Set the map's camera position to the current location of the device.
                            mLastKnownLocation = task.result
                            mMap.moveCamera(
                                CameraUpdateFactory.newLatLngZoom(
                                    LatLng(
                                        mLastKnownLocation.getLatitude(),
                                        mLastKnownLocation.getLongitude()
                                    ), DEFAULT_ZOOM
                                )
                            )
                        } else {
                            //Log.d(FragmentActivity.TAG, "Current location is null. Using defaults.")
                            //Log.e(FragmentActivity.TAG, "Exception: %s", task.exception)
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mDefaultLocation, DEFAULT_ZOOM))
                            mMap.uiSettings.isMyLocationButtonEnabled = false
                        }
                    }*/
                }
            }
        } catch (e: SecurityException) {
            Log.e("Exception: %s", e.message)
        }

        Toast.makeText(this, "Where do you want to run? Click to add a marker.",
            Toast.LENGTH_LONG).show()

    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (mMap != null) {
            outState.putParcelable(KEY_CAMERA_POSITION, mMap.cameraPosition)
            outState.putParcelable(KEY_LOCATION, mLastKnownLocation)
            super.onSaveInstanceState(outState)
        }
    }

    override fun onMapClick(latLng: LatLng) {
        /*Toast.makeText(
            this@MapsActivity,
            "onMapClick:\n" + latLng.latitude + " : " + latLng.longitude,
            Toast.LENGTH_LONG
        ).show()*/
    }

    override fun onMapLongClick(latLng: LatLng) {
        /*Toast.makeText(
            this@MapsActivity,
            "onMapLongClick:\n" + latLng.latitude + " : " + latLng.longitude,
            Toast.LENGTH_LONG
        ).show()*/

        //Add marker on LongClick position
        val markerOptions = MarkerOptions().position(latLng).title(latLng.toString())
        markerOptions.draggable(true)

        mMap.addMarker(markerOptions)
    }

    override fun onMarkerDragStart(marker: Marker) {
        marker.title = marker.position.toString()
        marker.showInfoWindow()
        marker.alpha = 0.5f
    }

    override fun onMarkerDrag(marker: Marker) {
        marker.title = marker.position.toString()
        marker.showInfoWindow()
        marker.alpha = 0.5f
    }

    override fun onMarkerDragEnd(marker: Marker) {
        marker.title = marker.position.toString()
        marker.showInfoWindow()
        marker.alpha = 1.0f
        Toast.makeText(this, "Current location:\n" + roundToDecimals(marker.position.latitude, 2) + ", " +
            roundToDecimals(marker.position.longitude, 2), Toast.LENGTH_LONG).show()
        //RetrieveFeedTask().execute()
        findParks(marker.position.latitude, marker.position.longitude)

        //GET https://prescriptiontrails.org/api/filter/?by=coord&lat=35.138321399999995&lng=-106.6676598&offset=0&count=2

    }

    fun findParks(lat: Double, long: Double) {
        var params = HashMap<String, String>()
        params.put("term", "parks")
        params.put("latitude", lat.toString())
        params.put("longitude", long.toString())
        //var response = call.execute()

        var call = yelpFusionApi.getBusinessSearch(params)

        var callback = object: Callback<SearchResponse> {
            override fun onResponse(call: Call<SearchResponse>?, response: retrofit2.Response<SearchResponse>?) {
                val searchResponse = response!!.body()
                Log.d("TAG", searchResponse.businesses.toString())

                var businesses = searchResponse.getBusinesses()
                var businessName = businesses.get(0).getName() // "JapaCurry Truck"
                //var rating = businesses.get(0).getRating() // 4.0

                var trails = arrayOfNulls<String>(businesses.size)
                for (i in 0 until businesses.size) {
                    trails[i] = businesses.get(i).name
                }

                //val miles = number.text.toString()
                val intent = Intent(this@MapsActivity, Trails::class.java)
                intent.putExtra("trails", trails)
                startActivity(intent)

                Log.d("Tag2", businessName)
            }

            override fun onFailure(call: Call<SearchResponse>?, t: Throwable?) {
                Log.d("TAG", "fail")
                //throw [t]
            }

            fun onResponse(call:Call<SearchResponse>, response:Response<SearchResponse>) {
                // Update UI text with the searchResponse.
            }

        }
        call.enqueue(callback)

        /*var searchResponse = call.execute().body()
        var totalNumberOfResult = searchResponse.getTotal() // 3
        var businesses = searchResponse.getBusinesses()
        var businessName = businesses.get(0).getName() // "JapaCurry Truck"
        var rating = businesses.get(0).getRating() // 4.0*/
        //Log.d("TAG", searchResponse.toString())

        Toast.makeText(this, "Found your trails!", Toast.LENGTH_LONG).show()

    }

    fun roundToDecimals(number: Double, numDecimalPlaces: Int): Double {
        val factor = Math.pow(10.0, numDecimalPlaces.toDouble())
        return Math.round(number * factor) / factor
    }

    public class RetrieveFeedTask: AsyncTask<Void, Void, String>() {
        //private val exception:Exception
        val API_KEY = "soZ0YyMTI2eAP7TMNWr1le9xkEHgpTvD0ZuRfzpWa0aOcODvN6sJO9mEGbTd9cwslSkR_y38lpXIX2w4bD2Mg9eJApnxqc6P2cAxBJ9I2N7W9jTCiSsYLPgJl63AXHYx"
        val API_URL = "https://api.yelp.com/v3/businesses/{id}"

        override protected fun onPreExecute() {
            //progressBar.setVisibility(View.VISIBLE)
            //responseView.setText("")
        }

        override protected fun doInBackground(vararg urls:Void):String? {
            //val email = emailText.getText().toString()
            // Do some validation here
            try
            {
                val url = URL(API_URL + "term=parks&latitude=" + 10.0 + "&longitude=" + 10.0 +
                        "&apiKey=" + API_KEY)
                val urlConnection = url.openConnection() as HttpURLConnection
                try
                {
                    val bufferedReader = BufferedReader(InputStreamReader(urlConnection.getInputStream()))
                    val stringBuilder = StringBuilder()
                    val line:String
                    while ((bufferedReader.readLine()) != null) {
                        stringBuilder.append(bufferedReader.readLine()).append("\n")
                    }
                    bufferedReader.close()
                    return stringBuilder.toString()
                }
                finally
                {
                    urlConnection.disconnect()
                }
            }
            catch (e:Exception) {
                Log.e("ERROR", e.message, e)
                return null
            }
        }

        override fun onProgressUpdate(vararg values: Void?) {
            super.onProgressUpdate(*values)
        }

        override protected fun onPostExecute(response: String) {
            //if (response == null)
            //{
            //    response = "THERE WAS AN ERROR"
            //}
            //progressBar.setVisibility(View.GONE)
            //Log.i("INFO", response)
            //responseView.setText(response)
            //Toast.makeText(this@MapsActivity response, Toast.LENGTH_LONG).show()
            println(response)
            Log.d("TAG", response)



            try
            {
                val `object` = JSONTokener(response).nextValue() as JSONObject
                val requestID = `object`.getString("requestId")
                val likelihood = `object`.getInt("likelihood")
                val photos = `object`.getJSONArray("photos")
            }
            catch (e: JSONException) {
                // Appropriate error handling code
            }
        }
    }

    /*fun makeRequest() {
        val jsonBody = JSONObject();
        jsonBody.put({ json: true, auth:
            { 'bearer': 'soZ0YyMTI2eAP7TMNWr1le9xkEHgpTvD0ZuRfzpWa0aOcODvN6sJO9mEGbTd9cwslSkR_y38lpXIX2w4bD2Mg9eJApnxqc6P2cAxBJ9I2N7W9jTCiSsYLPgJl63AXHYx'}});
        jsonBody.put("description", "Test");
        val jsonObjReq = JsonObjectRequest(
            DownloadManager.Request.Method.GET, url,
            Response.Listener<JSONObject> { response -> //Do Yo Thang }
                Response.ErrorListener { error -> }
                )
                val queue = Volley.newRequestQueue(this)
                queue.add(jsonObjReq)
                queue.start()


            }
    }*/


}
