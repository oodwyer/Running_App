package com.example.afinal

import android.app.DownloadManager
import android.content.Intent
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v7.app.AppCompatActivity
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private var total = "0.1"
    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_dashboard -> {
                val intent = Intent(this, Trails::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_notifications -> {
                val intent = Intent(this, Stats::class.java)
                //intent.putExtra("miles", total)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)

        map_button.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }

        logrun.setOnClickListener {
            val intent = Intent(this, Log::class.java)
            startActivity(intent)
        }

        //var total = intent.getStringExtra("miles")
        //if (total == null) {
        //    total = "0.0"
        //}

        val url = "http://shibe.online/api/shibes?count=1&urls=true&httpsUrls=false"
        val queue = Volley.newRequestQueue(this)
// Request a string response from the provided URL.
        /*val stringRequest = StringRequest(
            DownloadManager.Request.Method.GET, url,
            Response.Listener<String> { response ->
                getDoggo(response)
            }, Response.ErrorListener { println("ERROR!") }
        )*/

    }

    fun getDoggo(doggo: String) {
        System.out.println(doggo.subSequence(2, doggo.length-2))
        val dogurl = doggo.subSequence(2, doggo.length-2)

        //Picasso.get()
         //   .load(dogurl.toString()) // load the image
        //    .into(imageView3)
    }

}
